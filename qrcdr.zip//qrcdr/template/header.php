<div class="bg-primary position-relative">
  <div class="overlay-gradient"></div>
  <div class="container position-relative">
  	<div class="row py-5">
    	<div class="col">
        <h1 class="display-1">QR Code Generator</h1>
        <p>This is an example of header.<br>Place here your contents, or remove the file <code>/template/<span class="bg-danger text-white px-1">header.php</span></code>.</p>
        <p><a href="#" class="btn btn-primary btn-lg shadow" role="button">Learn more &raquo;</a></p>
    </div>
    </div>
  </div>
</div>